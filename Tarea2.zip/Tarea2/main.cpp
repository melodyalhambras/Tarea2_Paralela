#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

using namespace std;

void Llenararreglo(int A[],int N);
void Mostrararreglo(int A[], int N);
void Promedio(int A[], int N, float&promedio,float& sumapromedio);
void Varianza(int A[],int N, float& sumavarianza,float& varianza,float promedio);
void DesviacionEstandar(float&desviacion, float varianza);

int main()
{
    int N=10000;
    int A[N];
    int menu = 0;
    float promedio, varianza, sumavarianza=0,sumapromedio=0,desviacion;

    while (menu != 6){

      cout << "Elige una opción"<<endl<<endl;
      cout << "1. Llenar el arreglo con enteros al azar"<<endl;
      cout << "2. Mostrar el arreglo"<<endl;
      cout << "3. Calcular el promedio"<<endl;
      cout << "4. Calcular la varianza"<<endl;
      cout << "5. Calcular la desviacion estandar"<<endl;
      cout << "6. Para Salir: "<<endl;
      cout << "Eleccion: "<<endl;
      cin >> menu;

        switch (menu){
          case 1:
              Llenararreglo(A,N);
              cout << "Llenado exitoso"<<endl<<endl;
              break;
          case 2:
              Mostrararreglo(A,N);
              cout <<endl;
              break;
          case 3:
              Promedio(A,N,promedio,sumapromedio);
              cout << "El promedio es: " << promedio <<endl<<endl;
              break;
          case 4:
              Varianza(A,N,sumavarianza,varianza,promedio);
              cout << "La varianza es: " << varianza <<endl<<endl;
              break;
          case 5:
              DesviacionEstandar(desviacion,varianza);
              cout << "La desviacion estandar es: " << sqrt(varianza) <<endl<<endl;
              break;
          case 6:
              cout << "Salir"<<endl;
        }
    }
}



void Llenararreglo(int A[],int N)
{
    srand(time(NULL));
    cout<<"Lenar el arreglo con números aleatorios: "<<endl;
    for(int i=0; i<N;i++)
    {
        A[i]=rand()%100; //Genera números aleatorios hasta 100
    }
}

void Mostrararreglo(int A[], int N){

    for (int i=0; i<N; i++){
    cout<<"Numero "<<i<<" en el arreglo: "<<A[i]<<endl;

    }
}

void Promedio(int A[], int N, float&promedio,float& sumapromedio)
{
        for(int i =0 ; i<N;i++)
        {
        sumapromedio=sumapromedio+A[i];
        promedio=sumapromedio/N;

        }
}


void Varianza(int A[],int N, float& sumavarianza,float& varianza,float promedio)
{

    float x,y,denominador;
    for(int i =0 ; i<N ;i++){
    x=A[i]-promedio;
    y=x*x;
    sumavarianza=y+sumavarianza;
    denominador=N-1;
    varianza=sumavarianza/denominador;
    }
}

void DesviacionEstandar(float&desviacion, float varianza)
{
     desviacion=sqrt(varianza);
}



